# Fe-Ga XRD Peak Analysis Toolkit

A small Python toolkit that turns a raw powder X-ray diffraction (XRD) pattern of a BCC-based **Fe-Ga (Galfenol)** alloy into a table of peak positions, d-spacings, a lattice parameter, and a check for weak **B2 / D0₃ ordering peaks**.

I built it after my BS Physics thesis, *"Atomistic Variation of Magnetostriction in Fe-Ga Alloys"* (Karakoram International University, Gilgit). In that thesis, magnetostriction in Fe₇₃Ga₂₇ depends strongly on heat treatment because quenching and aging change which disordered (A2) or ordered (D0₃, B2) phases form. During the thesis I plotted XRD and magnetostriction data by hand in Origin. This project repeats that kind of XRD analysis in code so that it is repeatable, scriptable and easy to apply to many samples at once.

> **Data note.** The files in `data/` marked `_SYNTHETIC` are **artificially generated** to demonstrate the pipeline. They are not measurements and prove nothing about real Fe-Ga samples. Replace them with your own pattern (see below).

## What the pipeline does

1. Loads a two-column file (2θ in degrees, intensity).
2. Smooths the signal (Savitzky-Golay) and removes the background (asymmetric least squares).
3. Detects peaks (`scipy.signal.find_peaks`) and fits each one with a **pseudo-Voigt** profile.
4. Converts 2θ to d-spacing with **Bragg's law**, `d = λ / (2 sin θ)`.
5. Matches the strongest peaks to A2 (110), (200), (211) and computes the cubic lattice parameter `a`.
6. Looks for **candidate ordering peaks** at the positions expected from `a`: D0₃ (111), B2 (100)/D0₃ (200), B2 (111).
7. Estimates crystallite size with the **Scherrer equation** (rough lower bound; instrument broadening is ignored).

## Demo result (synthetic data)

| Pattern | Peaks found | Mean `a` (Å) | D0₃ (111) found | B2 (100) found |
|---|---|---|---|---|
| `demo_disordered_SYNTHETIC` | 3 (A2 only) | 2.910 | No | No |
| `demo_ordered_SYNTHETIC` | 5 (A2 + 2 weak) | 2.910 | Yes | Yes |

The script recovers the lattice parameter used to generate the demo data (2.91 Å) and separates the "disordered" pattern from the "ordered" one.

![Ordered synthetic pattern](figures/demo_ordered_SYNTHETIC.png)

## Quick start

```bash
git clone https://github.com/<your-username>/fega-xrd-analysis.git
cd fega-xrd-analysis
pip install -r requirements.txt

# run on the synthetic demo patterns
python src/make_demo_data.py
python src/run_analysis.py --input data/demo_ordered_SYNTHETIC.csv

# run on your own pattern (Cu K-alpha1 by default)
python src/run_analysis.py --input data/my_sample.csv --wavelength 1.5406
```

Outputs: a peak table in `results/` (CSV) and an annotated figure in `figures/`.

## Using your own data

- Format: a `.csv` or `.txt` file, two numeric columns (`2theta`, `intensity`), no header needed. Separators are detected automatically.
- Export from Origin: *File → Export → ASCII* (or copy the two columns into a text file).
- Use the correct wavelength for your instrument (`--wavelength`, in Å).

## Project layout

```
fega-xrd-analysis/
├── data/        synthetic demo patterns (replace with your own)
├── figures/     annotated plots
├── results/     peak tables (CSV)
├── src/
│   ├── xrd_analysis.py     core functions
│   ├── run_analysis.py     command line interface
│   └── make_demo_data.py   synthetic data generator
└── requirements.txt
```

## Limitations (please read)

- Phase labels are **candidate labels for screening**. Real phase identification needs reference patterns (ICDD/COD), Rietveld refinement and expert judgement.
- Weak superlattice peaks can be hidden by noise, texture or sample preparation, and D0₃ and B2 are hard to tell apart from lab XRD alone.
- The matching assumes a lattice parameter near 2.80 to 3.00 Å, which fits Fe-Ga but not other systems.
- Scherrer sizes ignore instrument and strain broadening.

## Possible next steps

- Compare patterns from several heat treatments (as-quenched, quasi-quenched, aged) and plot the lattice parameter and ordering-peak intensity against treatment.
- Link the XRD features to measured magnetostriction values and test simple regression models (scikit-learn).
- Add reference-pattern matching and a Jupyter notebook walkthrough.

## Tech

Python · NumPy · SciPy · pandas · Matplotlib

## Author

Jameel Hussain, BS Physics, Karakoram International University. Contact: jameelhussain5577@gmail.com
